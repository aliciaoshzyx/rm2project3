module.exports.Account = require('./Account.js');
module.exports.Song = require('./Song.js');
module.exports.Artist = require('./Artist.js');
module.exports.Album = require('./Album.js');
module.exports.Comment = require('./Comment.js');
